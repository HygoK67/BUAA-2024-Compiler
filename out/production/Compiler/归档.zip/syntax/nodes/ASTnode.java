package syntax.nodes;

public class ASTnode {
}
