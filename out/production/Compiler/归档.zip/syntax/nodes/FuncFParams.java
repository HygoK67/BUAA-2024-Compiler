package syntax.nodes;

import java.util.ArrayList;

public class FuncFParams {
    public ArrayList<FuncFParam> funcFParams = new ArrayList<>();
}
