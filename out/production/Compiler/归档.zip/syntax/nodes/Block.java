package syntax.nodes;

import java.util.ArrayList;

public class Block {
    public ArrayList<BlockItem> blockItems = new ArrayList<>();
}
