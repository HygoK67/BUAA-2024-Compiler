package syntax.nodes;

public class FuncFParam {
    public Btype btype;
    public Ident ident;
    public boolean isArray;
}
