package syntax;

public class SyntaxAnalysisException {
    private int lineNum;
    private char errorCode; // 'i', 'j', 'k' 分别代表了缺少分号，右小括号，右中括号

    public SyntaxAnalysisException(int lineNum, char errorCode) {
        this.lineNum = lineNum;
        this.errorCode = errorCode;
    }

    public int getLineNumber() {
        return lineNum;
    }

    public char getErrorCode() {
        return errorCode;
    }
}
