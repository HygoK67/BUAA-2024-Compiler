package lexical;

public class LexicalException {
    private int lineNum;
    private int errorCode;

    public LexicalException(int lineNum, int errorCode) {
        this.lineNum = lineNum;
        this.errorCode = errorCode;
    }

    public int getLineNumber() {
        return lineNum;
    }

    public int getErrorCode() {
        return errorCode;
    }
}
