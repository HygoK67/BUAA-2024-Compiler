package syntax.nodes;

public enum Btype {
    INT,
    CHAR
}
