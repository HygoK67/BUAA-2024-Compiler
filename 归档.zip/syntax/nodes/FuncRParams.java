package syntax.nodes;

import java.util.ArrayList;

public class FuncRParams extends ASTnode {
    public ArrayList<BiOperandExp> exps = new ArrayList<>();
}
