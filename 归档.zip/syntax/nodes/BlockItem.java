package syntax.nodes;

public class BlockItem {
    public Decl decl;
    public Stmt stmt;
}
